(()=>{var e={};e.id=768,e.ids=[768],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1017:e=>{"use strict";e.exports=require("path")},7310:e=>{"use strict";e.exports=require("url")},1306:(e,t,i)=>{"use strict";i.r(t),i.d(t,{GlobalError:()=>a.a,__next_app__:()=>m,originalPathname:()=>c,pages:()=>p,routeModule:()=>x,tree:()=>d}),i(5381),i(5425),i(5515),i(5866);var r=i(3191),n=i(8716),s=i(7922),a=i.n(s),o=i(5231),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);i.d(t,l);let d=["",{children:["resident",{children:["proxy",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(i.bind(i,5381)),"C:\\Users\\info\\.gemini\\antigravity\\app\\resident\\proxy\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(i.bind(i,5425)),"C:\\Users\\info\\.gemini\\antigravity\\app\\resident\\layout.tsx"],metadata:{icon:[async e=>(await Promise.resolve().then(i.bind(i,7481))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(i.bind(i,5515)),"C:\\Users\\info\\.gemini\\antigravity\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(i.t.bind(i,5866,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(i.bind(i,7481))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],p=["C:\\Users\\info\\.gemini\\antigravity\\app\\resident\\proxy\\page.tsx"],c="/resident/proxy/page",m={require:i,loadChunk:()=>Promise.resolve()},x=new r.AppPageRouteModule({definition:{kind:n.x.APP_PAGE,page:"/resident/proxy/page",pathname:"/resident/proxy",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},4222:(e,t,i)=>{Promise.resolve().then(i.bind(i,284))},5313:(e,t,i)=>{Promise.resolve().then(i.bind(i,9014))},1694:(e,t,i)=>{Promise.resolve().then(i.bind(i,4382)),Promise.resolve().then(i.bind(i,329))},4636:(e,t,i)=>{Promise.resolve().then(i.t.bind(i,2994,23)),Promise.resolve().then(i.t.bind(i,6114,23)),Promise.resolve().then(i.t.bind(i,9727,23)),Promise.resolve().then(i.t.bind(i,9671,23)),Promise.resolve().then(i.t.bind(i,1868,23)),Promise.resolve().then(i.t.bind(i,4759,23))},284:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>n});var r=i(326);function n({children:e}){return r.jsx(r.Fragment,{children:e})}i(7577)},9014:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>o});var r=i(326),n=i(7577),s=i(5047);function a(){let e=(0,s.useSearchParams)(),t=e.get("title")||"",i=e.get("date")||"",n=e.get("signer")||"",a=e.get("agent")||"",o=e.get("text")||"",l=(e=>{if(!e)return"";let t=e.split("-");if(3===t.length){let e=parseInt(t[0],10),i=parseInt(t[1],10),r=parseInt(t[2],10);if(!isNaN(e)&&!isNaN(i)&&!isNaN(r)){let t=e-2018,n="令和";e<2019&&(t=e-1988,n="平成");let s=1===t?"元":String(t);return`${n}${s}年${i}月${r}日`}}return e})(i);return(0,r.jsxs)("div",{className:"outer-proxy-wrapper bg-white min-h-screen p-8 md:p-16 flex items-center justify-center",children:[r.jsx("style",{children:`
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;700;900&display=swap');
        body {
          font-family: 'Noto Sans JP', sans-serif;
          background-color: #fff;
          color: #333;
          margin: 0;
          padding: 0;
        }
        .proxy-container {
          padding: 60px 50px;
          width: 100%;
          max-width: 700px;
          min-height: 800px;
          background: #fff;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
        }
        .proxy-top-date {
          text-align: right;
          font-size: 16px;
          font-weight: 700;
          margin-bottom: 60px;
        }
        .proxy-title {
          text-align: center;
          font-size: 32px;
          font-weight: 900;
          margin-bottom: 60px;
          letter-spacing: 0.5em;
          text-indent: 0.5em;
        }
        .proxy-body-text {
          font-size: 17px;
          line-height: 2;
          margin-bottom: 80px;
          white-space: pre-wrap;
          font-weight: bold;
          text-indent: 1em;
        }
        .proxy-signatures {
          margin-top: auto;
          space-y: 24px;
        }
        .proxy-sig-row {
          font-size: 18px;
          margin-bottom: 24px;
          display: flex;
          align-items: flex-end;
        }
        .proxy-sig-row:last-child {
          margin-bottom: 0;
        }
        .proxy-sig-date {
          font-weight: bold;
        }
        .proxy-sig-label {
          width: 100px;
          font-weight: bold;
        }
        .proxy-sig-value {
          font-size: 22px;
          font-weight: 900;
          border-bottom: 1.5px solid #000;
          width: 300px;
          padding-bottom: 4px;
          text-align: left;
        }
        @media print {
          @page {
            size: A4 portrait;
            margin: 0;
          }
          html, body {
            height: auto !important;
            min-height: initial !important;
            overflow: visible !important;
            background: none !important;
          }
          .outer-proxy-wrapper {
            min-height: initial !important;
            height: auto !important;
            display: block !important;
            padding: 60px !important;
            margin: 0 !important;
            background: none !important;
          }
          .proxy-container {
            max-width: 100% !important;
            box-shadow: none !important;
            page-break-inside: avoid !important;
            min-height: initial !important;
            padding: 0 !important;
          }
        }
      `}),(0,r.jsxs)("div",{className:"proxy-container",children:[r.jsx("div",{className:"proxy-body-text",children:o||`私は、${t}に出席できませんので、同総会における議決権を委任します。`}),(0,r.jsxs)("div",{className:"proxy-signatures",children:[r.jsx("div",{className:"proxy-sig-row",children:r.jsx("span",{className:"proxy-sig-date",children:l})}),(0,r.jsxs)("div",{className:"proxy-sig-row",children:[r.jsx("span",{className:"proxy-sig-label",children:"(本人)"}),r.jsx("span",{className:"proxy-sig-value",children:n})]}),a&&(0,r.jsxs)("div",{className:"proxy-sig-row",children:[r.jsx("span",{className:"proxy-sig-label",children:"(代理人)"}),r.jsx("span",{className:"proxy-sig-value",children:a})]})]})]})]})}function o(){return r.jsx(n.Suspense,{fallback:r.jsx("div",{className:"p-8 text-center text-gray-500",children:"読み込み中..."}),children:r.jsx(a,{})})}},4382:(e,t,i)=>{"use strict";i.d(t,{default:()=>r});let r=(0,i(3265).default)(async()=>{},{loadableGenerated:{modules:["components\\DynamicLiffProvider.tsx -> ./LiffProvider"]},ssr:!1})},329:(e,t,i)=>{"use strict";i.d(t,{default:()=>l});var r=i(326),n=i(7577),s=i.n(n),a=i(434);let o=[{name:"ホーム",href:"/",icon:"fas fa-home",bg:"var(--color-primary)",subLink:"ホームの詳細はこちら"},{name:"ポータル",href:"/portal",icon:"fas fa-th",bg:"#6366f1",subLink:"ポータルの利用方法はこちら"},{name:"マニュアル",href:"/manual",icon:"fas fa-book",bg:"#10b981",subLink:"会員の登録はこちら"},{name:"設定",href:"/admin",icon:"fas fa-cog",bg:"#f59e0b",subLink:"役員の登録はこちら"}];function l(){return r.jsx("nav",{className:"menu-container",children:o.map(e=>(0,r.jsxs)(s().Fragment,{children:[(0,r.jsxs)(a.default,{href:e.href,className:"menu-btn",style:{background:e.bg},children:[r.jsx("i",{className:e.icon+" menu-icon"}),e.name]}),r.jsx("p",{className:"sub-link",children:e.subLink})]},e.name))})}},5047:(e,t,i)=>{"use strict";var r=i(7389);i.o(r,"useRouter")&&i.d(t,{useRouter:function(){return r.useRouter}}),i.o(r,"useSearchParams")&&i.d(t,{useSearchParams:function(){return r.useSearchParams}})},5515:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>u,metadata:()=>x});var r=i(9510);i(7732);var n=i(8570);let s=(0,n.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\components\DynamicLiffProvider.tsx`),{__esModule:a,$$typeof:o}=s;s.default;let l=(0,n.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\components\DynamicLiffProvider.tsx#default`),d=(0,n.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\components\Menu.tsx`),{__esModule:p,$$typeof:c}=d;d.default;let m=(0,n.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\components\Menu.tsx#default`),x={title:"el-town",description:"町内会・自治会向け電子回覧板アプリ el-town"};function u({children:e}){return(0,r.jsxs)("html",{lang:"ja",children:[(0,r.jsxs)("head",{children:[r.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),r.jsx("link",{href:"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css",rel:"stylesheet"}),r.jsx("link",{href:"https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Noto+Sans+JP:wght@400;700;900&display=swap",rel:"stylesheet"})]}),r.jsx("body",{className:"antialiased",children:(0,r.jsxs)(l,{children:[r.jsx("p",{className:"subtitle",children:"町内会・自治会DXアプリ"}),r.jsx(m,{}),e]})})]})}},5425:(e,t,i)=>{"use strict";i.r(t),i.d(t,{$$typeof:()=>a,__esModule:()=>s,default:()=>o});var r=i(8570);let n=(0,r.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\app\resident\layout.tsx`),{__esModule:s,$$typeof:a}=n;n.default;let o=(0,r.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\app\resident\layout.tsx#default`)},5381:(e,t,i)=>{"use strict";i.r(t),i.d(t,{$$typeof:()=>a,__esModule:()=>s,default:()=>o});var r=i(8570);let n=(0,r.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\app\resident\proxy\page.tsx`),{__esModule:s,$$typeof:a}=n;n.default;let o=(0,r.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\app\resident\proxy\page.tsx#default`)},7481:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>n});var r=i(6621);let n=e=>[{type:"image/x-icon",sizes:"16x16",url:(0,r.fillMetadataSegment)(".",e.params,"favicon.ico")+""}]},7732:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),r=t.X(0,[948,511,621],()=>i(1306));module.exports=r})();