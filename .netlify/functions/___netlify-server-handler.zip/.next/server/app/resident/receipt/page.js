(()=>{var e={};e.id=451,e.ids=[451],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1017:e=>{"use strict";e.exports=require("path")},7310:e=>{"use strict";e.exports=require("url")},277:(e,t,i)=>{"use strict";i.r(t),i.d(t,{GlobalError:()=>a.a,__next_app__:()=>m,originalPathname:()=>p,pages:()=>d,routeModule:()=>x,tree:()=>c}),i(4038),i(5425),i(5515),i(5866);var r=i(3191),s=i(8716),n=i(7922),a=i.n(n),o=i(5231),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);i.d(t,l);let c=["",{children:["resident",{children:["receipt",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(i.bind(i,4038)),"C:\\Users\\info\\.gemini\\antigravity\\app\\resident\\receipt\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(i.bind(i,5425)),"C:\\Users\\info\\.gemini\\antigravity\\app\\resident\\layout.tsx"],metadata:{icon:[async e=>(await Promise.resolve().then(i.bind(i,7481))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(i.bind(i,5515)),"C:\\Users\\info\\.gemini\\antigravity\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(i.t.bind(i,5866,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(i.bind(i,7481))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],d=["C:\\Users\\info\\.gemini\\antigravity\\app\\resident\\receipt\\page.tsx"],p="/resident/receipt/page",m={require:i,loadChunk:()=>Promise.resolve()},x=new r.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/resident/receipt/page",pathname:"/resident/receipt",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},4222:(e,t,i)=>{Promise.resolve().then(i.bind(i,284))},9968:(e,t,i)=>{Promise.resolve().then(i.bind(i,5525))},1694:(e,t,i)=>{Promise.resolve().then(i.bind(i,4382)),Promise.resolve().then(i.bind(i,329))},4636:(e,t,i)=>{Promise.resolve().then(i.t.bind(i,2994,23)),Promise.resolve().then(i.t.bind(i,6114,23)),Promise.resolve().then(i.t.bind(i,9727,23)),Promise.resolve().then(i.t.bind(i,9671,23)),Promise.resolve().then(i.t.bind(i,1868,23)),Promise.resolve().then(i.t.bind(i,4759,23))},284:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>s});var r=i(326);function s({children:e}){return r.jsx(r.Fragment,{children:e})}i(7577)},5525:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>o});var r=i(326),s=i(7577),n=i(5047);function a(){let e=(0,n.useSearchParams)(),t=e.get("amount")||"0",i=e.get("name")||"",s=e.get("date")||"",a=e.get("town")||"",o=e.get("txId")||"",l=e.get("method")||"";return(0,r.jsxs)("div",{className:"outer-receipt-wrapper bg-white min-h-screen p-4 md:p-8 flex items-center justify-center",children:[r.jsx("style",{children:`
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;700;900&display=swap');
        body {
          font-family: 'Noto Sans JP', sans-serif;
          background-color: #fff;
          color: #333;
          margin: 0;
          padding: 0;
        }
        .receipt-container {
          border: 3px double #4b5563;
          padding: 20px 24px;
          width: 100%;
          max-width: 550px;
          background: #fff;
          position: relative;
          box-sizing: border-box;
        }
        .receipt-header {
          text-align: center;
          margin-bottom: 12px;
        }
        .receipt-header h1 {
          font-size: 22px;
          font-weight: 900;
          margin: 0 0 4px 0;
          letter-spacing: 0.5em;
          text-indent: 0.5em;
          color: #111827;
        }
        .receipt-line {
          width: 80px;
          height: 2px;
          background-color: #4b5563;
          margin: 0 auto;
        }
        .receipt-date {
          text-align: right;
          font-size: 11px;
          color: #6b7280;
          margin-bottom: 10px;
        }
        .receipt-target {
          font-size: 15px;
          font-weight: 700;
          border-bottom: 2px solid #374151;
          padding-bottom: 4px;
          margin-bottom: 10px;
          width: 70%;
        }
        .receipt-amount {
          text-align: center;
          font-size: 18px;
          font-weight: 900;
          background-color: #f9fafb;
          border: 1px solid #e5e7eb;
          padding: 10px;
          margin: 12px 0;
          border-radius: 8px;
          letter-spacing: 1px;
        }
        .receipt-details {
          margin-bottom: 15px;
          font-size: 12px;
        }
        .receipt-row {
          display: flex;
          justify-content: space-between;
          margin-bottom: 6px;
          border-bottom: 1px dashed #e5e7eb;
          padding-bottom: 3px;
        }
        .receipt-label {
          color: #6b7280;
          font-weight: bold;
        }
        .receipt-value {
          font-weight: bold;
          color: #1f2937;
        }
        .receipt-footer {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          margin-top: 15px;
          border-top: 1px solid #e5e7eb;
          padding-top: 10px;
        }
        .receipt-issuer {
          font-size: 12px;
          font-weight: 700;
        }
        .receipt-issuer p {
          margin: 2px 0;
        }
        .receipt-stamp {
          border: 2px solid #ef4444;
          color: #ef4444;
          width: 55px;
          height: 55px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          font-weight: bold;
          transform: rotate(-10deg);
          opacity: 0.85;
          user-select: none;
          text-align: center;
          line-height: 1.2;
        }
        @media print {
          @page {
            margin: 0; /* マージンを完全にゼロにする */
          }
          html, body {
            height: auto !important;
            min-height: initial !important;
            overflow: visible !important;
            background: none !important;
          }
          .outer-receipt-wrapper {
            min-height: initial !important;
            height: auto !important;
            display: block !important;
            padding: 20px !important; /* 周囲に適度なマージンを印刷時に直接持たせる */
            margin: 0 !important;
            background: none !important;
          }
          .receipt-container {
            border: 3px double #000;
            max-width: 100% !important;
            box-shadow: none !important;
            page-break-inside: avoid !important;
          }
        }
      `}),(0,r.jsxs)("div",{className:"receipt-container",children:[(0,r.jsxs)("div",{className:"receipt-date",children:["発行日: ",s]}),(0,r.jsxs)("div",{className:"receipt-header",children:[r.jsx("h1",{children:"領収書"}),r.jsx("div",{className:"receipt-line"})]}),(0,r.jsxs)("div",{className:"receipt-target",children:[i," 様"]}),r.jsx("p",{style:{fontSize:"12px",fontWeight:"bold",margin:0},children:"金額として、下記のとおり領収いたしました。"}),(0,r.jsxs)("div",{className:"receipt-amount",children:["領収金額： \xa5",parseInt(t).toLocaleString(),"-"]}),(0,r.jsxs)("div",{className:"receipt-details",children:[(0,r.jsxs)("div",{className:"receipt-row",children:[r.jsx("span",{className:"receipt-label",children:"但し書き"}),r.jsx("span",{className:"receipt-value",children:"会費として"})]}),(0,r.jsxs)("div",{className:"receipt-row",children:[r.jsx("span",{className:"receipt-label",children:"お支払方法"}),r.jsx("span",{className:"receipt-value",children:l})]}),(0,r.jsxs)("div",{className:"receipt-row",children:[r.jsx("span",{className:"receipt-label",children:"領収日"}),r.jsx("span",{className:"receipt-value",children:s})]}),(0,r.jsxs)("div",{className:"receipt-row",style:{borderBottom:"none"},children:[r.jsx("span",{className:"receipt-label",children:"決済番号"}),r.jsx("span",{className:"receipt-value",style:{fontFamily:"monospace"},children:o})]})]}),(0,r.jsxs)("div",{className:"receipt-footer",children:[(0,r.jsxs)("div",{className:"receipt-issuer",children:[r.jsx("p",{style:{fontSize:"10px",color:"#6b7280",marginBottom:"3px"},children:"領収者"}),r.jsx("p",{style:{fontSize:"14px",fontWeight:"900",color:"#111827"},children:a}),r.jsx("p",{style:{fontSize:"8px",color:"#6b7280",fontWeight:"normal"},children:"el-town オンライン集金受領"})]}),(0,r.jsxs)("div",{className:"receipt-stamp",children:[a.slice(0,3),r.jsx("br",{}),"領収済"]})]})]})]})}function o(){return r.jsx(s.Suspense,{fallback:r.jsx("div",{className:"p-8 text-center text-gray-500",children:"読み込み中..."}),children:r.jsx(a,{})})}},4382:(e,t,i)=>{"use strict";i.d(t,{default:()=>r});let r=(0,i(3265).default)(async()=>{},{loadableGenerated:{modules:["components\\DynamicLiffProvider.tsx -> ./LiffProvider"]},ssr:!1})},329:(e,t,i)=>{"use strict";i.d(t,{default:()=>l});var r=i(326),s=i(7577),n=i.n(s),a=i(434);let o=[{name:"ホーム",href:"/",icon:"fas fa-home",bg:"var(--color-primary)",subLink:"ホームの詳細はこちら"},{name:"ポータル",href:"/portal",icon:"fas fa-th",bg:"#6366f1",subLink:"ポータルの利用方法はこちら"},{name:"マニュアル",href:"/manual",icon:"fas fa-book",bg:"#10b981",subLink:"会員の登録はこちら"},{name:"設定",href:"/admin",icon:"fas fa-cog",bg:"#f59e0b",subLink:"役員の登録はこちら"}];function l(){return r.jsx("nav",{className:"menu-container",children:o.map(e=>(0,r.jsxs)(n().Fragment,{children:[(0,r.jsxs)(a.default,{href:e.href,className:"menu-btn",style:{background:e.bg},children:[r.jsx("i",{className:e.icon+" menu-icon"}),e.name]}),r.jsx("p",{className:"sub-link",children:e.subLink})]},e.name))})}},5047:(e,t,i)=>{"use strict";var r=i(7389);i.o(r,"useRouter")&&i.d(t,{useRouter:function(){return r.useRouter}}),i.o(r,"useSearchParams")&&i.d(t,{useSearchParams:function(){return r.useSearchParams}})},5515:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>u,metadata:()=>x});var r=i(9510);i(7732);var s=i(8570);let n=(0,s.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\components\DynamicLiffProvider.tsx`),{__esModule:a,$$typeof:o}=n;n.default;let l=(0,s.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\components\DynamicLiffProvider.tsx#default`),c=(0,s.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\components\Menu.tsx`),{__esModule:d,$$typeof:p}=c;c.default;let m=(0,s.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\components\Menu.tsx#default`),x={title:"el-town",description:"町内会・自治会向け電子回覧板アプリ el-town"};function u({children:e}){return(0,r.jsxs)("html",{lang:"ja",children:[(0,r.jsxs)("head",{children:[r.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),r.jsx("link",{href:"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css",rel:"stylesheet"}),r.jsx("link",{href:"https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Noto+Sans+JP:wght@400;700;900&display=swap",rel:"stylesheet"})]}),r.jsx("body",{className:"antialiased",children:(0,r.jsxs)(l,{children:[r.jsx("p",{className:"subtitle",children:"町内会・自治会DXアプリ"}),r.jsx(m,{}),e]})})]})}},5425:(e,t,i)=>{"use strict";i.r(t),i.d(t,{$$typeof:()=>a,__esModule:()=>n,default:()=>o});var r=i(8570);let s=(0,r.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\app\resident\layout.tsx`),{__esModule:n,$$typeof:a}=s;s.default;let o=(0,r.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\app\resident\layout.tsx#default`)},4038:(e,t,i)=>{"use strict";i.r(t),i.d(t,{$$typeof:()=>a,__esModule:()=>n,default:()=>o});var r=i(8570);let s=(0,r.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\app\resident\receipt\page.tsx`),{__esModule:n,$$typeof:a}=s;s.default;let o=(0,r.createProxy)(String.raw`C:\Users\info\.gemini\antigravity\app\resident\receipt\page.tsx#default`)},7481:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>s});var r=i(6621);let s=e=>[{type:"image/x-icon",sizes:"16x16",url:(0,r.fillMetadataSegment)(".",e.params,"favicon.ico")+""}]},7732:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),r=t.X(0,[948,511,621],()=>i(277));module.exports=r})();